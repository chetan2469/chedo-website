<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Privacy Policy | Chedo Tech</title>
  <meta name="description" content="Chedo Tech privacy policy — how information is handled on this static website: no data stored by the enquiry form, no analytics, minimal automatic collection.">
  <meta name="robots" content="noindex, follow">
  <link rel="canonical" href="https://chedo.in/privacy-policy.php">
  <link rel="icon" type="image/png" href="assets/logo.png">
  <link rel="apple-touch-icon" href="assets/logo.png">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Chedo Tech">
  <meta property="og:title" content="Privacy Policy | Chedo Tech">
  <meta property="og:description" content="Chedo Tech privacy policy — how information is handled on this static website: no data stored by the enquiry form, no analytics, minimal automatic collection.">
  <meta property="og:url" content="https://chedo.in/privacy-policy.html">
  <meta property="og:image" content="https://chedo.in/assets/images/og-image.png">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Privacy Policy | Chedo Tech">
  <meta name="twitter:description" content="Chedo Tech privacy policy — how information is handled on this static website: no data stored by the enquiry form, no analytics, minimal automatic collection.">
  <meta name="twitter:image" content="https://chedo.in/assets/images/og-image.png">
  <link rel="preload" href="assets/fonts/inter-latin.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="assets/css/main.css">
  <script defer src="assets/js/config.js"></script>
  <script defer src="assets/js/main.js"></script>
  </head>

<a class="skip-link" href="#main">Skip to main content</a>
<header class="site-header" id="site-header">
  <div class="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 sm:px-8">
    <a href="index.php" class="flex shrink-0 items-center gap-2.5" aria-label="Chedo Tech — Home">
      <img src="assets/logo.png" alt="Chedo Tech Logo" width="38" height="38" class="h-9 w-9 object-contain">
      <span class="text-lg font-extrabold tracking-tight text-slate-900">Chedo<span class="text-blue-600">Tech</span></span>
    </a>

    <nav class="hidden items-center gap-0.5 lg:flex" aria-label="Main navigation">
      <a class="nav-link active" href="index.php">Home</a>
      <div class="dropdown relative" id="courses-drop">
        <button id="courses-drop-btn" class="nav-link flex items-center gap-1" aria-haspopup="true" aria-expanded="false">
          Courses
          <svg class="h-4 w-4 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div class="dropdown-panel" role="menu" aria-label="Courses">
          <div class="grid grid-cols-2 gap-x-4 gap-y-3"><div><p class="drop-head">Programming</p><div class="grid gap-0.5"><a class="dropdown-link" href="courses/c-programming.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1" />
  <path d="M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1" />
</svg>
</span><span class="text-sm font-medium text-slate-700">C Programming</span></a><a class="dropdown-link" href="courses/cpp-programming.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m18 16 4-4-4-4" />
  <path d="m6 8-4 4 4 4" />
  <path d="m14.5 4-5 16" />
</svg>
</span><span class="text-sm font-medium text-slate-700">C++ Programming</span></a><a class="dropdown-link" href="courses/java-programming.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 2v2" />
  <path d="M14 2v2" />
  <path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1" />
  <path d="M6 2v2" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Java Programming</span></a><a class="dropdown-link" href="courses/python-programming.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z" />
  <path d="M14 2v5a1 1 0 0 0 1 1h5" />
  <path d="M10 12.5 8 15l2 2.5" />
  <path d="m14 12.5 2 2.5-2 2.5" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Python Programming</span></a><a class="dropdown-link" href="courses/data-structures-algorithms.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="16" y="16" width="6" height="6" rx="1" />
  <rect x="2" y="16" width="6" height="6" rx="1" />
  <rect x="9" y="2" width="6" height="6" rx="1" />
  <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
  <path d="M12 12V8" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Data Structures & Algorithms</span></a></div></div><div><p class="drop-head">Development</p><div class="grid gap-0.5"><a class="dropdown-link" href="courses/mern-full-stack.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
  <path d="M2 12h20" />
</svg>
</span><span class="text-sm font-medium text-slate-700">MERN Full Stack</span></a><a class="dropdown-link" href="courses/java-full-stack.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="8" x="2" y="2" rx="2" ry="2" />
  <rect width="20" height="8" x="2" y="14" rx="2" ry="2" />
  <line x1="6" x2="6.01" y1="6" y2="6" />
  <line x1="6" x2="6.01" y1="18" y2="18" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Java Full Stack</span></a><a class="dropdown-link" href="courses/mobile-app-development.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
  <path d="M12 18h.01" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Mobile App Development</span></a></div></div><div><p class="drop-head">Data & Design</p><div class="grid gap-0.5"><a class="dropdown-link" href="courses/data-science-foundation.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 3v18" />
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M3 9h18" />
  <path d="M3 15h18" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Data Science Foundation</span></a><a class="dropdown-link" href="courses/data-science.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" />
  <path d="M6.453 15h11.094" />
  <path d="M8.5 2h7" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Data Science</span></a><a class="dropdown-link" href="courses/ui-ux-design.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z" />
  <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" />
  <circle cx="17.5" cy="10.5" r=".5" fill="currentColor" />
  <circle cx="6.5" cy="12.5" r=".5" fill="currentColor" />
  <circle cx="8.5" cy="7.5" r=".5" fill="currentColor" />
</svg>
</span><span class="text-sm font-medium text-slate-700">UI/UX Design</span></a></div></div><div><p class="drop-head">Kids</p><div class="grid gap-0.5"><a class="dropdown-link" href="courses/kids-programming.php"><span class="drop-icon"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-[18px] w-[18px]"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <line x1="6" x2="10" y1="11" y2="11" />
  <line x1="8" x2="8" y1="9" y2="13" />
  <line x1="15" x2="15.01" y1="12" y2="12" />
  <line x1="18" x2="18.01" y1="10" y2="10" />
  <path d="M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z" />
</svg>
</span><span class="text-sm font-medium text-slate-700">Kids Programming</span></a></div></div></div>
          <a class="mt-3 flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3 text-sm font-semibold text-blue-700 transition-colors hover:bg-blue-50" href="courses.php">
            View all courses
            <!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-4 w-4"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="m12 5 7 7-7 7" />
</svg>

          </a>
        </div>
      </div>
      <a class="nav-link" href="about.php">About</a>
      <a class="nav-link" href="contact.php">Contact</a>
      <a class="btn-primary ml-3 !px-5 !py-2.5 !min-h-0" href="contact.php">Enquire Now</a>
    </nav>

    <button id="menu-btn" class="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700 lg:hidden" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu">
      <!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-5 w-5"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 5h16" />
  <path d="M4 12h16" />
  <path d="M4 19h16" />
</svg>

    </button>
  </div>

  <div id="mobile-menu" class="mobile-panel lg:hidden">
    <nav aria-label="Mobile navigation" class="px-5 py-4">
      <a class="mob-link" href="index.php">Home</a>
      <button id="mob-courses-btn" class="mob-link justify-between" aria-expanded="false" aria-controls="mob-courses-list">
        Courses
        <!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-4 w-4 text-slate-400"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m6 9 6 6 6-6" />
</svg>

      </button>
      <div id="mob-courses-list" class="hidden border-l-2 border-slate-100 pb-2 pl-3">
        <p class="drop-head">Programming</p><a class="mob-sub-link" href="courses/c-programming.php">C Programming</a><a class="mob-sub-link" href="courses/cpp-programming.php">C++ Programming</a><a class="mob-sub-link" href="courses/java-programming.php">Java Programming</a><a class="mob-sub-link" href="courses/python-programming.php">Python Programming</a><a class="mob-sub-link" href="courses/data-structures-algorithms.php">Data Structures & Algorithms</a><p class="drop-head">Development</p><a class="mob-sub-link" href="courses/mern-full-stack.php">MERN Full Stack</a><a class="mob-sub-link" href="courses/java-full-stack.php">Java Full Stack</a><a class="mob-sub-link" href="courses/mobile-app-development.php">Mobile App Development</a><p class="drop-head">Data & Design</p><a class="mob-sub-link" href="courses/data-science-foundation.php">Data Science Foundation</a><a class="mob-sub-link" href="courses/data-science.php">Data Science</a><a class="mob-sub-link" href="courses/ui-ux-design.php">UI/UX Design</a><p class="drop-head">Kids</p><a class="mob-sub-link" href="courses/kids-programming.php">Kids Programming</a>
      </div>
      <a class="mob-link" href="about.php">About</a>
      <a class="mob-link" href="contact.php">Contact</a>
      <a class="btn-primary mt-3 w-full" href="contact.php">Enquire Now</a>
    </nav>
  </div>
</header>

<main id="main">

<section class="py-16 sm:py-20">
  <div class="mx-auto max-w-3xl px-5 sm:px-8">
    <nav aria-label="Breadcrumb" class="mb-6"><ol class="flex flex-wrap items-center gap-2 text-sm text-slate-500"><li><a class="transition-colors hover:text-blue-700" href="index.php">Home</a></li><li class="text-slate-300" aria-hidden="true">/</li><li class="text-slate-600" aria-current="page">Privacy Policy</li></ol></nav>
    <h1 class="text-[clamp(2rem,4.5vw,3.25rem)] font-extrabold leading-tight tracking-tight text-slate-900">Privacy Policy</h1>
    <p class="mt-3 text-sm font-medium text-slate-500">Last updated: August 2026</p>
    <p class="mt-6 leading-relaxed text-slate-600">
      Chedo Tech (chedo.in) runs a simple static website for a programming institute in Pune.
      This page explains, in plain language, how information is handled — which is very little.
    </p>
    <section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">What This Policy Covers</h2>
      <p class="mt-3 leading-relaxed text-slate-600">This policy describes how chedo.in ("Chedo Tech", "we", "us") handles information when you visit this website. It applies only to this website, not to any third-party platforms we may link to.</p>
    </section><section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">Information You Send Us</h2>
      <p class="mt-3 leading-relaxed text-slate-600">This is a static website. The enquiry form does not submit data to any server: it opens WhatsApp on your own device with your message pre-filled. Any information you choose to send us — by WhatsApp, phone, email, or in person — is used only to respond to your enquiry and to help you with course guidance.</p>
    </section><section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">Information We Collect Automatically</h2>
      <p class="mt-3 leading-relaxed text-slate-600">This website is served as plain static files and currently does not use analytics trackers, cookies or advertising scripts. Your hosting provider or network may keep standard server logs (such as IP addresses and requested pages) as part of normal operation.</p>
    </section><section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">Third-Party Services</h2>
      <p class="mt-3 leading-relaxed text-slate-600">The site may link to third-party services such as WhatsApp, Google Maps and other platforms. Those services have their own privacy policies, and we are not responsible for their practices. If a Google Maps embed is enabled on the contact page, Google may set cookies according to its own policy.</p>
    </section><section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">Children's Privacy</h2>
      <p class="mt-3 leading-relaxed text-slate-600">We offer a kids programming course. Parents or guardians make all enquiries and provide any information on behalf of children. We do not knowingly collect personal information from children through this website.</p>
    </section><section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">Your Choices</h2>
      <p class="mt-3 leading-relaxed text-slate-600">You can contact us at any time to ask what information you have shared with us, to correct it, or to ask that we delete it. Our contact details are listed on the contact page.</p>
    </section><section class="mt-10">
      <h2 class="text-xl font-bold tracking-tight text-slate-900">Changes to This Policy</h2>
      <p class="mt-3 leading-relaxed text-slate-600">If this website later adds analytics, third-party forms or new features, this page will be updated accordingly. The date below shows the latest revision.</p>
    </section>
  </div>
</section>

</main>

<footer class="border-t border-slate-200 bg-slate-50">
  <div class="mx-auto max-w-7xl px-5 pb-10 pt-14 sm:px-8 lg:pt-16">
    <div class="grid gap-10 lg:grid-cols-12">
      <div class="lg:col-span-3">
        <a href="index.php" class="inline-flex items-center gap-2.5">
          <img src="assets/logo.png" alt="Chedo Tech Logo" width="38" height="38" class="h-9 w-9 object-contain">
          <span class="text-lg font-extrabold tracking-tight text-slate-900">Chedo<span class="text-blue-600">Tech</span></span>
        </a>
        <p class="mt-3 text-sm font-medium text-slate-600">Programming Institute &amp; App Development</p>
        <p class="mt-2 max-w-xs text-sm leading-relaxed text-slate-500">Offline, practical programming education since 2015 — from basics to building real projects.</p>
        <p class="mt-4 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 font-mono text-[11px] font-semibold tracking-wide text-slate-500">
          <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span> Offline &middot; Practical &middot; Project-Based
        </p>
      </div>
      <div class="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-6">
        <nav aria-label="Programming courses">
          <h2 class="font-mono text-[11px] font-semibold uppercase tracking-widest text-slate-500">Programming</h2>
          <ul class="mt-3 space-y-0.5">
            <li><a class="footer-link" href="courses/c-programming.php">C</a></li><li><a class="footer-link" href="courses/cpp-programming.php">C++</a></li><li><a class="footer-link" href="courses/java-programming.php">Java</a></li><li><a class="footer-link" href="courses/python-programming.php">Python</a></li><li><a class="footer-link" href="courses/data-structures-algorithms.php">Data Structures & Algorithms</a></li>
          </ul>
        </nav>
        <nav aria-label="Development courses">
          <h2 class="font-mono text-[11px] font-semibold uppercase tracking-widest text-slate-500">Development</h2>
          <ul class="mt-3 space-y-0.5">
            <li><a class="footer-link" href="courses/mern-full-stack.php">MERN Full Stack</a></li><li><a class="footer-link" href="courses/java-full-stack.php">Java Full Stack</a></li><li><a class="footer-link" href="courses/mobile-app-development.php">Mobile App Development</a></li><li><a class="footer-link" href="courses/data-science.php">Data Science</a></li>
          </ul>
        </nav>
        <nav aria-label="Other courses">
          <h2 class="font-mono text-[11px] font-semibold uppercase tracking-widest text-slate-500">Other</h2>
          <ul class="mt-3 space-y-0.5">
            <li><a class="footer-link" href="courses/data-science-foundation.php">Data Science Foundation</a></li><li><a class="footer-link" href="courses/ui-ux-design.php">UI/UX Design</a></li><li><a class="footer-link" href="courses/kids-programming.php">Kids Programming</a></li>
          </ul>
        </nav>
      </div>
      <div class="grid grid-cols-2 gap-8 lg:col-span-3">
        <nav aria-label="Explore">
          <h2 class="font-mono text-[11px] font-semibold uppercase tracking-widest text-slate-500">Explore</h2>
          <ul class="mt-3 space-y-0.5">
            <li><a class="footer-link" href="index.php">Home</a></li><li><a class="footer-link" href="courses.php">Courses</a></li><li><a class="footer-link" href="about.php">About</a></li><li><a class="footer-link" href="contact.php">Contact</a></li>
          </ul>
        </nav>
        <nav aria-label="Contact">
          <h2 class="font-mono text-[11px] font-semibold uppercase tracking-widest text-slate-500">Contact</h2>
          <ul class="mt-3 space-y-0.5">
<li><a class="footer-link" href="contact.php"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-4 w-4"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384" />
</svg>
 <span data-phone>Set in config.js</span></a></li>
<li><a class="footer-link" href="contact.php"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-4 w-4"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719" />
</svg>
 WhatsApp Enquiry</a></li>
<li><a class="footer-link" href="contact.php"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-4 w-4"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0" />
  <circle cx="12" cy="10" r="3" />
</svg>
 <span data-address>Set in config.js</span></a></li>
<li><a class="footer-link" href="contact.php"><!-- @license lucide-static v1.28.0 - ISC -->
<svg aria-hidden="true" focusable="false"
  class="h-4 w-4"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7" />
  <rect x="2" y="4" width="20" height="16" rx="2" />
</svg>
 <span data-email>Set in config.js</span></a></li>
</ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="border-t border-slate-200">
    <div class="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-5 py-5 text-sm text-slate-500 sm:flex-row sm:px-8">
      <p>&copy; <span id="year">2026</span> Chedo Tech. All rights reserved.</p>
      <a class="font-medium text-slate-500 transition-colors hover:text-blue-700" href="privacy-policy.php">Privacy Policy</a>
    </div>
  </div>
</footer>

</body>
</html>
